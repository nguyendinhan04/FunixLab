EndPoint: database-1.c5cgwm0o4822.ap-southeast-1.rds.amazonaws.com
User: admin
password: 21NhaanChinhs
database: asmdb
url: jdbc:mysql://database-1.c5cgwm0o4822.ap-southeast-1.rds.amazonaws.com:3306/asmdb
