Host: asm-cluster2.cbfra1lvveaj.ap-southeast-1.redshift.amazonaws.com
Port: 5439
user: awsuser
pass: 21NhaanChinhs
database: dev
url: jdbc:redshift://asm-cluster2.cbfra1lvveaj.ap-southeast-1.redshift.amazonaws.com:5439/dev